package dsa4;
public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;
    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }
    public void addEmployee(Employee employee) {
        if (size < employees.length) {
            employees[size] = employee;
            size++;
            System.out.println("Employee added: " + employee);
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }
    public Employee searchEmployee(String employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }
    public void displayAllEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }
    public void deleteEmployee(String employeeId) {
        int index = -1;
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            for (int i = index; i < size - 1; i++) {
                employees[i] = employees[i + 1];
            }
            employees[size - 1] = null;
            size--;
            System.out.println("Employee deleted: " + employeeId);
        } else {
            System.out.println("Employee with ID " + employeeId + " not found.");
        }
    }

    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem(5);
        Employee emp1 = new Employee("E001", "Asma", "Manager", 75000);
        Employee emp2 = new Employee("E002", "Aryan", "Developer", 60000);
        Employee emp3 = new Employee("E003", "Nidhi", "Designer", 50000);
        system.addEmployee(emp1);
        system.addEmployee(emp2);
        system.addEmployee(emp3);
        System.out.println("\nAll Employees:");
        system.displayAllEmployees();
        System.out.println("\nSearch Employee E002:");
        Employee foundEmp = system.searchEmployee("E002");
        System.out.println(foundEmp);
        System.out.println("\nDelete Employee E002:");
        system.deleteEmployee("E002");
        System.out.println("\nAll Employees After Deletion:");
        system.displayAllEmployees();
    }
}
