package dsa7;
public class FinancialForecasting {
    public static double calculateFutureValue(double pastValue, double growthRate, int periods) {
        if (periods == 0) {
            return pastValue;
        }
        return calculateFutureValue(pastValue * (1 + growthRate), growthRate, periods - 1);
    }

    public static void main(String[] args) {
        double pastValue = 1000.0; 
        double growthRate = 0.05;  
        int periods = 10;          

        double futureValue = calculateFutureValue(pastValue, growthRate, periods);
        System.out.printf("Future value after %d periods: %.2f\n", periods, futureValue);
    }
}
