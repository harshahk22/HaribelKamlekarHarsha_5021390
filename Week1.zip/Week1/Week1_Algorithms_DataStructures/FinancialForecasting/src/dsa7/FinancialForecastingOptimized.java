package dsa7;
public class FinancialForecastingOptimized {
    public static double calculateFutureValueIterative(double pastValue, double growthRate, int periods) {
        double futureValue = pastValue;
        for (int i = 0; i < periods; i++) {
            futureValue *= (1 + growthRate);
        }
        return futureValue;
    }
    public static void main(String[] args) {
        double pastValue = 1000.0; 
        double growthRate = 0.05;  
        int periods = 10;          

        double futureValue = calculateFutureValueIterative(pastValue, growthRate, periods);
        System.out.printf("Future value after %d periods (Iterative): %.2f\n", periods, futureValue);
    }
}
