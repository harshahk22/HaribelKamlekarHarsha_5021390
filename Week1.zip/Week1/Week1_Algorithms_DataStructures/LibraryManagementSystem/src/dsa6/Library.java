package dsa6;
import java.util.Arrays;
import java.util.Comparator;

public class Library {
    private Book[] books;
    private int size;
    public Library(int capacity) {
        books = new Book[capacity];
        size = 0;
    }
    public void addBook(Book book) {
        if (size < books.length) {
            books[size] = book;
            size++;
        } else {
            System.out.println("Library is full. Cannot add more books.");
        }
    }
    public Book linearSearchByTitle(String title) {
        for (int i = 0; i < size; i++) {
            if (books[i].getTitle().equalsIgnoreCase(title)) {
                return books[i];
            }
        }
        return null;
    }
    public Book binarySearchByTitle(String title) {
        Arrays.sort(books, 0, size, Comparator.comparing(Book::getTitle, String::compareToIgnoreCase));
        int left = 0;
        int right = size - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int cmp = books[mid].getTitle().compareToIgnoreCase(title);
            if (cmp == 0) {
                return books[mid];
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
    public void displayAllBooks() {
        for (int i = 0; i < size; i++) {
            System.out.println(books[i]);
        }
    }
    public static void main(String[] args) {
        Library library = new Library(5);
        Book book1 = new Book("B001", "The Great Gatsby", "F. Scott Fitzgerald");
        Book book2 = new Book("B002", "To Kill a Mockingbird", "Harper Lee");
        Book book3 = new Book("B003", "1984", "George Orwell");
        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);
        System.out.println("\nAll Books:");
        library.displayAllBooks();
        System.out.println("\nLinear Search for '1984':");
        Book foundBookLinear = library.linearSearchByTitle("1984");
        System.out.println(foundBookLinear);
        System.out.println("\nBinary Search for '1984':");
        Book foundBookBinary = library.binarySearchByTitle("1984");
        System.out.println(foundBookBinary);
    }
}
