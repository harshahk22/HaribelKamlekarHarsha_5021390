package dsa3;
public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("O001", "Nidhi", 250.0),
            new Order("O002", "Asma", 150.0),
            new Order("O003", "Ravi", 300.0),
            new Order("O004", "Aryan", 200.0)
        };
        System.out.println("Bubble Sort:");
        BubbleSort.bubbleSort(orders);
        for (Order order : orders) {
            System.out.println(order);
        }
        System.out.println("\nQuick Sort:");
        QuickSort.quickSort(orders, 0, orders.length - 1);
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}
