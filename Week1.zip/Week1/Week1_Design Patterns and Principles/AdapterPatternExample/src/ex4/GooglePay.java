package ex4;

public class GooglePay {
	 public void executePayment(double amount) {
	        System.out.println("Processing payment through GooglePay: $" + amount);
	    }
}
