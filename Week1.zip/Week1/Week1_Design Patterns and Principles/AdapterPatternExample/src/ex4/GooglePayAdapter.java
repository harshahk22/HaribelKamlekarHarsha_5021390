package ex4;

public class GooglePayAdapter implements PaymentProcessor{
	    private GooglePay gpay;
	    public GooglePayAdapter(GooglePay gpay) {
	        this.gpay = gpay;
	    }
	    public void processPayment(double amount) {
	        gpay.executePayment(amount);
	    }
}
