package ex4;
public class Phonepe {
    public void sendPayment(double amount) {
        System.out.println("Processing payment through Phonepe: $" + amount);
    }
}