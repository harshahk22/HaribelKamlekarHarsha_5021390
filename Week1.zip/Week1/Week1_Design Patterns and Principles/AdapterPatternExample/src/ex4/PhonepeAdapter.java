package ex4;
public class PhonepeAdapter implements PaymentProcessor {
    private Phonepe ppay;

    public PhonepeAdapter(Phonepe ppay) {
        this.ppay = ppay;
    }
    public void processPayment(double amount) {
        ppay.sendPayment(amount);
    }
}