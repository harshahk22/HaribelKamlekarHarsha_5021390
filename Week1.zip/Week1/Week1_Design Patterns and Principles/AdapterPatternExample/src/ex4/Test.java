package ex4;
public class Test {
    public static void main(String[] args) {
        PayPal payPal = new PayPal();
        Phonepe ppay = new Phonepe();
        GooglePay gpay = new GooglePay();
        PaymentProcessor payPalProcessor = new PayPalAdapter(payPal);
        PaymentProcessor ppayProcessor = new PhonepeAdapter(ppay);
        PaymentProcessor gpayProcessor = new GooglePayAdapter(gpay);
        payPalProcessor.processPayment(100.0);
        ppayProcessor.processPayment(200.0);
        gpayProcessor.processPayment(300.0);
    }
}
