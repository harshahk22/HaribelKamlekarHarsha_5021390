package ex3;
public class Test {
    public static void main(String[] args) {
        Computer gamingComputer = new Computer.Builder("Intel i9", "32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setPowerSupply("750W")
                .setCoolingSystem("Liquid Cooling")
                .build();

        Computer officeComputer = new Computer.Builder("Intel i5", "16GB")
                .setStorage("512GB SSD")
                .build();

        Computer budgetComputer = new Computer.Builder("AMD Ryzen 3", "8GB")
                .setStorage("256GB SSD")
                .setPowerSupply("500W")
                .build();
        System.out.println(gamingComputer);
        System.out.println(officeComputer);
        System.out.println(budgetComputer);
    }
}
