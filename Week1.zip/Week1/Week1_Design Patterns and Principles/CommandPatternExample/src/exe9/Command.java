package exe9;
public interface Command {
 void execute();
}
