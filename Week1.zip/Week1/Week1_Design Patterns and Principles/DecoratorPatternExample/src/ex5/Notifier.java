package ex5;

public interface Notifier {
	void send(String msg);
}
