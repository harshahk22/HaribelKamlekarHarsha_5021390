package ex5;
public class Test {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier();
        Notifier smsEmailNotifier = new SMSNotifierDecorator(emailNotifier);
        Notifier slackSmsEmailNotifier = new SlackNotifierDecorator(smsEmailNotifier);
        System.out.println("Sending with Email only:");
        emailNotifier.send("Hello via Email");
        System.out.println("\nSending with Email and SMS:");
        smsEmailNotifier.send("Hello via Email and SMS");
        System.out.println("\nSending with Email, SMS, and Slack:");
        slackSmsEmailNotifier.send("Hello via Email, SMS, and Slack");
    }
}
