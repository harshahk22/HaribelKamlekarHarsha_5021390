package ex11;
public interface CustomerRepository {
 Customer findCustomerById(String id);
}
