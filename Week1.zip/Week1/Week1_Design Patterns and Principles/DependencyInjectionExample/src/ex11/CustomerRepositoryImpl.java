package ex11;
public class CustomerRepositoryImpl implements CustomerRepository {
 public Customer findCustomerById(String id) {
     return new Customer(id, "Aryan");
 }
}
