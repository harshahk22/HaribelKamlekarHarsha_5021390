package ex2;
	public interface Document {
	    void open();
	    void save();
	    void close();
	}
