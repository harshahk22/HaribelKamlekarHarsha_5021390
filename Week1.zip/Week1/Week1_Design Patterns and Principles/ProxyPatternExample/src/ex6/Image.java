package ex6;
public interface Image {
    void display();
}
