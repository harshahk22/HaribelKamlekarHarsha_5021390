package week1;

class Logger {
	    private static Logger log;
	    private Logger() {
	    }

	    public static Logger getInstance() {
	        if (log == null) {
	            synchronized (Logger.class) {
	                if (log == null) {
	                    log = new Logger();
	                }
	            }
	        }
	        return log;
	    }
	    public void log(String message) {
	        System.out.println("Log message: " + message);
	    }
}
public class Test {
    public static void main(String[] args) {
        Logger logger1 = Logger.getInstance();
        Logger logger2 = Logger.getInstance();
        logger1.log("This is the first log message.");
        logger2.log("This is the second log message.");
        if (logger1 == logger2) {
            System.out.println("Single instance has been created");
        } else {
            System.out.println("Different instances has been created");
        }
    }
}
