package ex9;
public interface PaymentStrategy {
    void pay(double amount);
}
