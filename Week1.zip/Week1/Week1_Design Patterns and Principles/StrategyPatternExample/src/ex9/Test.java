package ex9;
public class Test {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext();
        PaymentStrategy creditCardPayment = new CreditCardPayment("1297-5338-1976-5322", "Ravi", "123", "12/25");
        paymentContext.setPaymentStrategy(creditCardPayment);
        System.out.println("Executing payment with Credit Card:");
        paymentContext.executePayment(100.00);
        PaymentStrategy payPalPayment = new PayPalPayment("Ravi12@gmail.com", "securepassword");
        paymentContext.setPaymentStrategy(payPalPayment);
        System.out.println("\nExecuting payment with PayPal:");
        paymentContext.executePayment(200.00);
    }
}
