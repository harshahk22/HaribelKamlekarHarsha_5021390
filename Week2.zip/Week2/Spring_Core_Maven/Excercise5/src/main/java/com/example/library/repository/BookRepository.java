package com.example.library.repository;

public class BookRepository {

    // Add methods for BookRepository
    public void saveBook(String book) {
        System.out.println("Saving book: " + book);
    }

    // Other repository methods
}
