package com.example.library.service;

import com.example.library.repository.BookRepository;

public class BookService {

    @SuppressWarnings("unused")
	private BookRepository bookRepository;

    // Setter method for BookRepository
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Other methods for BookService
}
