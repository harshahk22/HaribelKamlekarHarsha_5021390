
package com.library.service;

import com.library.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    @Autowired
    public BookService(BookRepository bookRepository) {
    }
    public void setBookRepository(BookRepository bookRepository) {
    }
    public void performSomeService() {
        System.out.println("Service is performing some action.");
    }
}
